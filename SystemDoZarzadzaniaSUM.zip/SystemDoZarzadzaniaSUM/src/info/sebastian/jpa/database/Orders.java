package info.sebastian.jpa.database;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Orders {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	private String orderTitle;
	private String description;

	@ManyToOne
	@JoinColumn(name = "employee_id")
	private Employee employee;

	@ManyToOne
	@JoinColumn(name = "scenario_id")
	private Scenario scenario;

	@ManyToOne
	@JoinColumn(name = "firm_id")
	private PrivatePerson firm;

	@ManyToOne
	@JoinColumn(name = "private_preson_id")
	private PrivatePerson privatePerson;

	@OneToMany(mappedBy = "orders")
	private List<OrderDetails> orderDetails;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getOrderTitle() {
		return orderTitle;
	}

	public void setOrderTitle(String orderTitle) {
		this.orderTitle = orderTitle;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Scenario getScenario() {
		return scenario;
	}

	public void setScenario(Scenario scenario) {
		this.scenario = scenario;
	}

	public List<OrderDetails> getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(List<OrderDetails> orderDetails) {
		this.orderDetails = orderDetails;
	}

	public PrivatePerson getFirm() {
		return firm;
	}

	public void setFirm(PrivatePerson firm) {
		this.firm = firm;
	}

	public PrivatePerson getPrivatePerson() {
		return privatePerson;
	}

	public void setPrivatePerson(PrivatePerson privatePerson) {
		this.privatePerson = privatePerson;
	}

}
