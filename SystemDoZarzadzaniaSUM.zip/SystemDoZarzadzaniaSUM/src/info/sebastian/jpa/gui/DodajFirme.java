package info.sebastian.jpa.gui;

import info.sebastian.jpa.dao.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

class DodajFirme extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JLabel lNazwa, lAdres, lKod, lTelefon, lMail, lNip;
	private JTextField tNazwa, tAdres, tKod, tTelefon, tMail, tNip;
	private JButton bZatwierdz, bAnuluj;

	public DodajFirme(JFrame owner) {
		super(owner, "Podaj dane firmy", true);
		setSize(550, 300);
		setLayout(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		lNazwa = new JLabel("Nazwa firmy: ");
		lNazwa.setBounds(20, 20, 80, 20);
		add(lNazwa);

		lAdres = new JLabel("Adres: ");
		lAdres.setBounds(20, 50, 80, 20);
		add(lAdres);

		lKod = new JLabel("Kod: ");
		lKod.setBounds(20, 80, 80, 20);
		add(lKod);

		lTelefon = new JLabel("Nr telefonu: ");
		lTelefon.setBounds(20, 110, 80, 20);
		add(lTelefon);

		lMail = new JLabel("E-mail: ");
		lMail.setBounds(20, 140, 80, 20);
		add(lMail);

		lNip = new JLabel("NIP: ");
		lNip.setBounds(20, 170, 80, 20);
		add(lNip);

		tNazwa = new JTextField();
		tNazwa.setBounds(120, 20, 250, 20);
		add(tNazwa);

		tAdres = new JTextField();
		tAdres.setBounds(120, 50, 250, 20);
		add(tAdres);

		tKod = new JTextField();
		tKod.setBounds(120, 80, 250, 20);
		add(tKod);

		tTelefon = new JTextField();
		tTelefon.setBounds(120, 110, 250, 20);
		add(tTelefon);

		tMail = new JTextField();
		tMail.setBounds(120, 140, 250, 20);
		add(tMail);

		tNip = new JTextField();
		tNip.setBounds(120, 170, 250, 20);
		add(tNip);

		bZatwierdz = new JButton("Zatwierdź");
		bZatwierdz.setBounds(400, 50, 100, 20);
		bZatwierdz.addActionListener(this);
		add(bZatwierdz);

		bAnuluj = new JButton("Anuluj");
		bAnuluj.setBounds(400, 140, 100, 20);
		bAnuluj.addActionListener(this);
		add(bAnuluj);

	}

	public void actionPerformed(ActionEvent e) {
		Object zrodlo = e.getSource();
		if (zrodlo == bAnuluj)
			dispose();
		if (zrodlo == bZatwierdz) {
			FirmParameters firmParameters = new FirmParameters();
			firmParameters.setFirmName(tNazwa.getText());
			firmParameters.setPhoneNumber(tTelefon.getText());
			firmParameters.setMail(tMail.getText());
			firmParameters.setAddress(tAdres.getText());
			firmParameters.setZipCode(tKod.getText());
			firmParameters.setNip(tNip.getText());

			DataAccessObject.addFirm(firmParameters);
			JOptionPane.showMessageDialog(this, "Pomyślnie dodano klienta");
			setVisible(false);
		}
		tNazwa.setText(null);
		tTelefon.setText(null);
		tMail.setText(null);
		tAdres.setText(null);
		tKod.setText(null);
		tNip.setText(null);
	}

}
