package info.sebastian.jpa.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import info.sebastian.jpa.dao.DataAccessObject;
import info.sebastian.jpa.dao.OrderParameters;

class DodajZlecenie extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JLabel lTytul, lOpis, lKlient, lPracownik;
	private JTextField tTytul, tKlient, tPracownik;
	private JTextArea tOpis;
	private JButton bZatwierdz, bAnuluj;

	public DodajZlecenie(JFrame owner) {
		super(owner, "Podaj dane zlecenia", true);
		setSize(550, 400);
		setLayout(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		lTytul = new JLabel("Tytuł: ");
		lTytul.setBounds(20, 20, 80, 20);
		add(lTytul);

		lOpis = new JLabel("Opis: ");
		lOpis.setBounds(20, 50, 80, 20);
		add(lOpis);

		lKlient = new JLabel("ID klienta: ");
		lKlient.setBounds(20, 210, 80, 20);
		add(lKlient);

		lPracownik = new JLabel("Pracownik: ");
		lPracownik.setBounds(20, 240, 80, 20);
		add(lPracownik);

		tTytul = new JTextField();
		tTytul.setBounds(120, 20, 250, 20);
		add(tTytul);

		tOpis = new JTextArea();
		JScrollPane scOpis = new JScrollPane(tOpis);
		scOpis.setBounds(120, 50, 250, 150);
		add(scOpis);

		tKlient = new JTextField();
		tKlient.setBounds(120, 210, 250, 20);
		add(tKlient);

		tPracownik = new JTextField();
		tPracownik.setBounds(120, 240, 250, 20);
		add(tPracownik);

		bZatwierdz = new JButton("Zatwierdź");
		bZatwierdz.setBounds(400, 20, 100, 20);
		bZatwierdz.addActionListener(this);
		add(bZatwierdz);

		bAnuluj = new JButton("Anuluj");
		bAnuluj.setBounds(400, 80, 100, 20);
		bAnuluj.addActionListener(this);
		add(bAnuluj);

	}

	public void actionPerformed(ActionEvent e) {

		Object zrodlo = e.getSource();
		if (zrodlo == bAnuluj)
			dispose();
		if (zrodlo == bZatwierdz) {
			OrderParameters orderParameters = new OrderParameters();
			orderParameters.setOrderTitle(tTytul.getText());
			orderParameters.setDescription(tOpis.getText());

			DataAccessObject.addOrder(orderParameters);
			JOptionPane.showMessageDialog(this, "Pomyślnie dodano zlecenie");
			setVisible(false);
		}
		tTytul.setText(null);
		tOpis.setText(null);
	}

}
