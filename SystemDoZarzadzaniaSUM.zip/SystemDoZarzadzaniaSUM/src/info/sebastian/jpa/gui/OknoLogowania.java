package info.sebastian.jpa.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

class OknoLogowania extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JLabel lUzytkownik, lHaslo;
	private JTextField tUzytkownik;
	private JPasswordField pHaslo;
	private JButton bZaloguj, bAnuluj;

	public OknoLogowania(JFrame owner) {
		super(owner, "Podaj dane logowania", true);
		setSize(300, 300);
		setLayout(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		lUzytkownik = new JLabel("Użytkownik: ");
		lUzytkownik.setBounds(20, 50, 80, 20);
		add(lUzytkownik);

		lHaslo = new JLabel("Hasło: ");
		lHaslo.setBounds(20, 100, 80, 20);
		add(lHaslo);

		tUzytkownik = new JTextField();
		tUzytkownik.setBounds(100, 50, 150, 20);
		add(tUzytkownik);

		pHaslo = new JPasswordField();
		pHaslo.setBounds(100, 100, 150, 20);
		pHaslo.addActionListener(this);
		add(pHaslo);

		bZaloguj = new JButton("Zaloguj");
		bZaloguj.setBounds(30, 150, 100, 20);
		bZaloguj.addActionListener(this);
		add(bZaloguj);

		bAnuluj = new JButton("Anuluj");
		bAnuluj.setBounds(140, 150, 100, 20);
		bAnuluj.addActionListener(this);
		add(bAnuluj);

	}

	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent e) {

		Object zrodlo = e.getSource();
		if (zrodlo == bAnuluj)
			dispose();
		else if (zrodlo == bZaloguj || zrodlo == pHaslo) {
			if (tUzytkownik.getText().equals("admin")
					&& (pHaslo.getText().equals("admin"))) {
				OknoStartowe.iPZaloguj.setEnabled(false);
				OknoStartowe.iPWyloguj.setEnabled(true);
				OknoStartowe.mUzytkownik.setEnabled(true);
				OknoStartowe.mZlecenie.setEnabled(true);
				OknoStartowe.mKlient.setEnabled(true);
				OknoStartowe.mFaktura.setEnabled(true);
				OknoStartowe.mMagazyn.setEnabled(true);
				OknoStartowe.oknoLogowania.setVisible(false);
			} else if (tUzytkownik.getText().equals("dok")
					&& (pHaslo.getText().equals("dok"))) {
				OknoStartowe.iPZaloguj.setEnabled(false);
				OknoStartowe.iPWyloguj.setEnabled(true);
				OknoStartowe.mZlecenie.setEnabled(true);
				OknoStartowe.mKlient.setEnabled(true);
				OknoStartowe.mFaktura.setEnabled(true);
				OknoStartowe.oknoLogowania.setVisible(false);
			} else if (tUzytkownik.getText().equals("magazyn")
					&& (pHaslo.getText().equals("magazyn"))) {
				OknoStartowe.iPZaloguj.setEnabled(false);
				OknoStartowe.iPWyloguj.setEnabled(true);
				OknoStartowe.mMagazyn.setEnabled(true);
				OknoStartowe.oknoLogowania.setVisible(false);
			} else if (tUzytkownik.getText().equals("serwis")
					&& (pHaslo.getText().equals("serwis"))) {
				OknoStartowe.iPZaloguj.setEnabled(false);
				OknoStartowe.iPWyloguj.setEnabled(true);
				OknoStartowe.mZlecenie.setEnabled(true);
				OknoStartowe.mMagazyn.setEnabled(true);
				OknoStartowe.iMWprowadz.setEnabled(false);
				OknoStartowe.oknoLogowania.setVisible(false);

			} else
				JOptionPane.showMessageDialog(this,
						"Nieprawidłowy login lub hasło", "Błąd!",
						JOptionPane.ERROR_MESSAGE);
			tUzytkownik.setText(null);
			pHaslo.setText(null);
		}

	}

}
