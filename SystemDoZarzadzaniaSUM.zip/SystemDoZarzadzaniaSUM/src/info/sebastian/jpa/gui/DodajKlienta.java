package info.sebastian.jpa.gui;

import info.sebastian.jpa.dao.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

class DodajKlienta extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JLabel lImie, lNazwisko, lTelefon, lMail;
	private JTextField tImie, tNazwisko, tTelefon, tMail;
	private JButton bZatwierdz, bAnuluj;

	public DodajKlienta(JFrame owner) {
		super(owner, "Podaj dane klienta", true);
		setSize(550, 200);
		setLayout(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		lImie = new JLabel("Imię: ");
		lImie.setBounds(20, 20, 80, 20);
		add(lImie);

		lNazwisko = new JLabel("Nazwisko: ");
		lNazwisko.setBounds(20, 50, 80, 20);
		add(lNazwisko);

		lTelefon = new JLabel("Nr telefonu: ");
		lTelefon.setBounds(20, 80, 80, 20);
		add(lTelefon);

		lMail = new JLabel("E-mail: ");
		lMail.setBounds(20, 110, 80, 20);
		add(lMail);

		tImie = new JTextField();
		tImie.setBounds(120, 20, 250, 20);
		add(tImie);

		tNazwisko = new JTextField();
		tNazwisko.setBounds(120, 50, 250, 20);
		add(tNazwisko);

		tTelefon = new JTextField();
		tTelefon.setBounds(120, 80, 250, 20);
		add(tTelefon);

		tMail = new JTextField();
		tMail.setBounds(120, 110, 250, 20);
		add(tMail);

		bZatwierdz = new JButton("Zatwierdź");
		bZatwierdz.setBounds(400, 20, 100, 20);
		bZatwierdz.addActionListener(this);
		add(bZatwierdz);

		bAnuluj = new JButton("Anuluj");
		bAnuluj.setBounds(400, 80, 100, 20);
		bAnuluj.addActionListener(this);
		add(bAnuluj);

	}

	public void actionPerformed(ActionEvent e) {

		Object zrodlo = e.getSource();

		if (zrodlo == bAnuluj)
			dispose();
		if (zrodlo == bZatwierdz) {
			PrivatePersonParameters privatePersonParameters = new PrivatePersonParameters();
			privatePersonParameters.setFirstName(tImie.getText());
			privatePersonParameters.setLastName(tNazwisko.getText());
			privatePersonParameters.setPhoneNumber(tTelefon.getText());
			privatePersonParameters.setMail(tMail.getText());

			DataAccessObject.addPrivatePerson(privatePersonParameters);
			JOptionPane.showMessageDialog(this, "Pomyślnie dodano klienta");
			setVisible(false);
		}
		tImie.setText(null);
		tNazwisko.setText(null);
		tTelefon.setText(null);
		tMail.setText(null);
	}

}
