package info.sebastian.jpa.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//import javax.swing.JButton;
//import javax.swing.JDialog;
import javax.swing.JFrame;
//import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
//import javax.swing.JPasswordField;
//import javax.swing.JTextField;

//////////////////////////////////
//////////////
//////////////////////////////////

public class OknoStartowe extends JFrame implements ActionListener {

	public static final long serialVersionUID = 1L;
	public static OknoLogowania oknoLogowania;
	public static DodajKlienta dodajKlienta;
	public static DodajFirme dodajFirme;
	public static DodajZlecenie dodajZlecenie;
	public JMenuBar menuBar;
	public static JMenu mPlik, mUzytkownik, mZlecenie, mKlient, mKDodaj, mFaktura, mMagazyn;
	public static JMenuItem iPZaloguj, iPWyloguj, iPWyjscie, iUDodaj, iUEdytuj, iUUsun, iZNowe, iZEdytuj,
			iKIndywidualny, iKFirma, iKEdytuj, iKUsun, iFNowa, iFEdytuj, iFPodglad, iMWprowadz, iMPobierz,
			iMSprawdzStan;

	public OknoStartowe() {
		setTitle("Okno startowe");
		setSize(500, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);

		menuBar = new JMenuBar();

		mPlik = new JMenu("Plik");
		iPZaloguj = new JMenuItem("Zaloguj");
		iPWyloguj = new JMenuItem("Wyloguj");
		iPWyjscie = new JMenuItem("Wyjście");
		iPZaloguj.addActionListener(this);
		iPWyloguj.addActionListener(this);
		mPlik.add(iPZaloguj);
		mPlik.add(iPWyloguj);
		mPlik.addSeparator();
		mPlik.add(iPWyjscie);

		iPWyjscie.addActionListener(this);

		mUzytkownik = new JMenu("Użytkownik");
		iUDodaj = new JMenuItem("Dodaj");
		iUEdytuj = new JMenuItem("Edytuj");
		iUUsun = new JMenuItem("Usuń");
		mUzytkownik.add(iUDodaj);
		mUzytkownik.add(iUEdytuj);
		mUzytkownik.addSeparator();
		mUzytkownik.add(iUUsun);

		mZlecenie = new JMenu("Zlecenie");
		iZNowe = new JMenuItem("Nowe");
		iZNowe.addActionListener(this);
		iZEdytuj = new JMenuItem("Edytuj");
		mZlecenie.add(iZNowe);
		mZlecenie.add(iZEdytuj);

		mKlient = new JMenu("Klient");
		iKEdytuj = new JMenuItem("Edytuj");
		iKUsun = new JMenuItem("Usuń");

		mKDodaj = new JMenu("Dodaj");
		iKIndywidualny = new JMenuItem("Osoba prywatna");
		iKIndywidualny.addActionListener(this);
		iKFirma = new JMenuItem("Firma");
		iKFirma.addActionListener(this);
		mKDodaj.add(iKIndywidualny);
		mKDodaj.add(iKFirma);

		mKlient.add(mKDodaj);
		mKlient.add(iKEdytuj);
		mKlient.addSeparator();
		mKlient.add(iKUsun);

		mFaktura = new JMenu("Faktura");
		iFNowa = new JMenuItem("Nowa");
		iFEdytuj = new JMenuItem("Edytuj");
		iFPodglad = new JMenuItem("Podgląd");
		mFaktura.add(iFNowa);
		mFaktura.add(iFEdytuj);
		mFaktura.addSeparator();
		mFaktura.add(iFPodglad);

		mMagazyn = new JMenu("Magazyn");
		iMWprowadz = new JMenuItem("Wprowadź część");
		iMPobierz = new JMenuItem("Pobierz część");
		iMSprawdzStan = new JMenuItem("Sprawdź stan");
		mMagazyn.add(iMWprowadz);
		mMagazyn.add(iMPobierz);
		mMagazyn.addSeparator();
		mMagazyn.add(iMSprawdzStan);

		iPWyloguj.setEnabled(false);
		mUzytkownik.setEnabled(false);
		mZlecenie.setEnabled(false);
		mKlient.setEnabled(false);
		mFaktura.setEnabled(false);
		mMagazyn.setEnabled(false);

		setJMenuBar(menuBar);
		menuBar.add(mPlik);
		menuBar.add(mUzytkownik);
		menuBar.add(mZlecenie);
		menuBar.add(mKlient);
		menuBar.add(mFaktura);
		menuBar.add(mMagazyn);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object zrodlo = e.getSource();
		if (zrodlo == iPWyjscie) {
			int odpowiedz = JOptionPane.showConfirmDialog(null, "Czy na pewno chcesz wyjść?", "Wyjście",
					JOptionPane.YES_NO_OPTION);
			if (odpowiedz == JOptionPane.YES_OPTION)
				dispose();
			else if (odpowiedz == JOptionPane.NO_OPTION)
				JOptionPane.getRootFrame();
			else if (odpowiedz == JOptionPane.CLOSED_OPTION)
				JOptionPane.getRootFrame();
		}

		if (zrodlo == iPZaloguj) {
			if (oknoLogowania == null)
				oknoLogowania = new OknoLogowania(this);
			oknoLogowania.setVisible(true);

		}

		if (zrodlo == iPWyloguj) {
			iPZaloguj.setEnabled(true);
			iPWyloguj.setEnabled(false);
			mUzytkownik.setEnabled(false);
			mZlecenie.setEnabled(false);
			mKlient.setEnabled(false);
			mFaktura.setEnabled(false);
			mMagazyn.setEnabled(false);
		}

		if (zrodlo == iKIndywidualny) {
			if (dodajKlienta == null)
				dodajKlienta = new DodajKlienta(this);
			dodajKlienta.setVisible(true);
		}

		if (zrodlo == iKFirma) {
			if (dodajFirme == null)
				dodajFirme = new DodajFirme(this);
			dodajFirme.setVisible(true);
		}

		if (zrodlo == iZNowe) {
			if (dodajZlecenie == null)
				dodajZlecenie = new DodajZlecenie(this);
			dodajZlecenie.setVisible(true);
		}
	}

}

// ////////////////////////////////
// ////////////
// ////////////////////////////////
