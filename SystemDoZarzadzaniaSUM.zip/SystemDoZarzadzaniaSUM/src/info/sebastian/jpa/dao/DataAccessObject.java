package info.sebastian.jpa.dao;

import info.sebastian.jpa.database.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DataAccessObject {

	public static void addFirm(FirmParameters firmParameters) {
		Firm firm = new Firm();
		firm.setFirmName(firmParameters.getFirmName());
		firm.setPhoneNumber(firmParameters.getPhoneNumber());
		firm.setMail(firmParameters.getMail());
		firm.setAddress(firmParameters.getAddress());
		firm.setZipCode(firmParameters.getZipCode());
		firm.setNip(firmParameters.getNip());

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myDatabase");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		entityManager.getTransaction().begin();
		entityManager.persist(firm);
		entityManager.getTransaction().commit();

		entityManager.close();
		entityManagerFactory.close();

	}

	public static void addPrivatePerson(PrivatePersonParameters privatePersonParameters) {
		PrivatePerson privatePerson = new PrivatePerson();
		privatePerson.setFirstName(privatePersonParameters.getFirstName());
		privatePerson.setLastName(privatePersonParameters.getLastName());
		privatePerson.setPhoneNumber(privatePersonParameters.getPhoneNumber());
		privatePerson.setMail(privatePersonParameters.getMail());

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myDatabase");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		entityManager.getTransaction().begin();
		entityManager.persist(privatePerson);
		entityManager.getTransaction().commit();

		entityManager.close();
		entityManagerFactory.close();

	}

	public static void addOrder(OrderParameters orderParameters) {
		Orders orders = new Orders();
		orders.setOrderTitle(orderParameters.getOrderTitle());
		orders.setDescription(orderParameters.getDescription());

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myDatabase");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		entityManager.getTransaction().begin();
		entityManager.persist(orders);
		entityManager.getTransaction().commit();

		entityManager.close();
		entityManagerFactory.close();

	}

}