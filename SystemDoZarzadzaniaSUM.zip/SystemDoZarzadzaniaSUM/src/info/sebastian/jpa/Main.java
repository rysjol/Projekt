package info.sebastian.jpa;
import info.sebastian.jpa.gui.OknoStartowe;

public class Main {
	
//	private static EntityManagerFactory entityManagerFactory;
	//private static EntityManager entityManager;

	public static void main(String[] args) {
		//EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myDatabase");
		//EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		//entityManagerFactory = Persistence.createEntityManagerFactory("myDatabase");
		//entityManager = entityManagerFactory.createEntityManager();
		
		OknoStartowe oknoStartowe = new OknoStartowe();
		oknoStartowe.setVisible(true);
		
		//entityManager.close();
		//entityManagerFactory.close();
		
		
	}

}
