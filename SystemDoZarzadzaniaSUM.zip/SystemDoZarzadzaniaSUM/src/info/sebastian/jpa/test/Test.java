package info.sebastian.jpa.test;

import info.sebastian.jpa.database.Firm;
import info.sebastian.jpa.database.Orders;
import info.sebastian.jpa.database.PrivatePerson;

import static org.junit.Assert.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

public class Test {

	@org.junit.Test
	public void testAddFirm() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myDatabase");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		Firm firm = new Firm();
		firm.setFirmName("F.H.U. RysPol");
		firm.setPhoneNumber("123456789");
		firm.setMail("ryspol@gmail.com");
		firm.setAddress("ul. Szeroka 5");
		firm.setZipCode("30-123 Zakopane");
		firm.setNip("1234567890");

		entityManager.getTransaction().begin();
		entityManager.persist(firm);
		entityManager.getTransaction().commit();

		entityManager.getTransaction().begin();

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Firm> criteriaQuery = builder.createQuery(Firm.class);
		Root<Firm> customer = criteriaQuery.from(Firm.class);

		Path<String> firmName = customer.get("firmName");
		criteriaQuery.select(customer).where(builder.equal(firmName, "F.H.U. RysPol"));

		TypedQuery<Firm> query = entityManager.createQuery(criteriaQuery);
		Firm result = query.getSingleResult();

		entityManager.getTransaction().commit();

		assertEquals("F.H.U. RysPol", result.getFirmName());
		assertEquals("123456789", result.getPhoneNumber());
		assertEquals("ryspol@gmail.com", result.getMail());
		assertEquals("ul. Szeroka 5", result.getAddress());
		assertEquals("30-123 Zakopane", result.getZipCode());
		assertEquals("1234567890", result.getNip());

		entityManager.getTransaction().begin();
		entityManager.remove(firm);
		entityManager.getTransaction().commit();

		entityManager.close();
		entityManagerFactory.close();

	}

	@org.junit.Test
	public void testAddPrivatePerson() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myDatabase");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		PrivatePerson privatePerson = new PrivatePerson();
		privatePerson.setFirstName("Bombom");
		privatePerson.setLastName("Kowalski");
		privatePerson.setPhoneNumber("987654321");
		privatePerson.setMail("bombom.kowalski@gmail.com");

		entityManager.getTransaction().begin();
		entityManager.persist(privatePerson);
		entityManager.getTransaction().commit();

		entityManager.getTransaction().begin();

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<PrivatePerson> criteriaQuery = builder.createQuery(PrivatePerson.class);
		Root<PrivatePerson> customer = criteriaQuery.from(PrivatePerson.class);

		Path<String> mail = customer.get("mail");
		criteriaQuery.select(customer).where(builder.equal(mail, "bombom.kowalski@gmail.com"));

		TypedQuery<PrivatePerson> query = entityManager.createQuery(criteriaQuery);
		PrivatePerson result = query.getSingleResult();

		entityManager.getTransaction().commit();

		assertEquals("Bombom", result.getFirstName());
		assertEquals("Kowalski", result.getLastName());
		assertEquals("987654321", result.getPhoneNumber());
		assertEquals("bombom.kowalski@gmail.com", result.getMail());

		entityManager.getTransaction().begin();
		entityManager.remove(privatePerson);
		entityManager.getTransaction().commit();

		entityManager.close();
		entityManagerFactory.close();

	}

	@org.junit.Test
	public void testAddOrder() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myDatabase");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		Orders orders = new Orders();
		orders.setOrderTitle("Naprawa Telefonu Samsung");
		orders.setDescription("Telefon posiada pekniety ekran dotykowy");

		entityManager.getTransaction().begin();
		entityManager.persist(orders);
		entityManager.getTransaction().commit();

		entityManager.getTransaction().begin();

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Orders> criteriaQuery = builder.createQuery(Orders.class);
		Root<Orders> order = criteriaQuery.from(Orders.class);

		Path<String> orderTitle = order.get("orderTitle");
		criteriaQuery.select(order).where(builder.equal(orderTitle, "Naprawa Telefonu Samsung"));

		TypedQuery<Orders> query = entityManager.createQuery(criteriaQuery);
		Orders result = query.getSingleResult();

		entityManager.getTransaction().commit();

		assertEquals("Naprawa Telefonu Samsung", result.getOrderTitle());
		assertEquals("Telefon posiada pekniety ekran dotykowy", result.getDescription());

		entityManager.getTransaction().begin();
		entityManager.remove(orders);
		entityManager.getTransaction().commit();

		entityManager.close();
		entityManagerFactory.close();

	}
}
